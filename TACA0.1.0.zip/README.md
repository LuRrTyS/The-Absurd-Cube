The Absurd  Cube (Alpha 0.1.0 - 0.1.1)

Welcome to the early alpha repository of my debut indie game built with Godot 4.5.1 

This is a compact, atmospheric pixel-art platformer focused on responsive movement, tight controls, and a very charismatic, slightly cursed little dark cube with eyelashes as the main protagonist.

🚀 Current Status: Alpha 0.1.1
The project is currently under active development. The main goal is to create a polished, finely-tuned 30-to-60 minute gameplay experience. 

What's working right now:
Core Movement: Smooth, responsive character physics and custom controller logic.
Sprite System: Custom-built $96 \times 96$ animation sheets for the protagonist.
World Grid: Fixed 2D environment setup aligned with the game physics.

Recent Updates (v0.1.1):
Fixed the first (of probably many) collision bugs.
Micro-adjustments to the character's idle and walking animation frames.

🛠️ Tech Stack
Engine: Godot 4.5.1
Language:GDScript
Art: Custom Pixel Art

📅 Roadmap / Next Steps
[ ] Implement basic UI (Score counter & main menu)
[ ] Design a full 3-minute "Vertical Slice" level
[ ] Add collectible items and level transition mechanics
